package org.example;
public class Arbalet implements Gun {
    @Override
    public String getFire() {
        return "ВЖИК";
    }
    public void  doMyInit() {
        System.out.println("Arbalet - Initialization");
    }
    public void doMyDestroy(){
        System.out.println("Arbalet - Destroyed");
    }

}
