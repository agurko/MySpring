package org.example;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.sql.SQLOutput;

public class Main {
    public static void main(String[] args) {
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
                "ApplicationContext.xml"
        );

    Unit unit = context.getBean("unit", Unit.class );
   unit.fireGunList();

    context.close();
    }
}