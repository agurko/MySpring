package org.example;

import org.springframework.stereotype.Component;

@Component("bazuka")
public class Bazuka implements Gun {
   public Bazuka(){}
    @Override
    public String getFire() {
        return "Базука-БАХ";
    }
    public void  doMyInit() {
        System.out.println("Bazuka - Initialization");
    }
    public void doMyDestroy(){
        System.out.println("Bazuka - Destroyed");
    }
}
