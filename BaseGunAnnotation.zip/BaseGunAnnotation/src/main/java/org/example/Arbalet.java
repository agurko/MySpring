package org.example;

import org.springframework.stereotype.Component;

@Component("arbalet")
public class Arbalet implements Gun {
    @Override
    public String getFire() {
        return "Арбалет-ВЖИК";
    }
    public void  doMyInit() {
        System.out.println("Arbalet - Initialization");
    }
    public void doMyDestroy(){
        System.out.println("Arbalet - Destroyed");
    }

}
