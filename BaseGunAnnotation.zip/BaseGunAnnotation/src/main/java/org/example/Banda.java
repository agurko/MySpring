package org.example;

import org.springframework.stereotype.Component;

@Component("banda")
public class Banda {
    private  String name;
    private Unit unit;

    public Banda(Unit unit) {
        this.name = "Банда";
        this.unit = unit;
    }

    @Override
    public String toString() {
        return "Banda{" +
                "name='" + name + '\'' +
                ", unit=" + unit +
                '}';
    }
}
