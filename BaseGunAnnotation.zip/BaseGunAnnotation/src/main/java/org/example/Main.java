package org.example;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.sql.SQLOutput;

public class Main {
    public static void main(String[] args) {
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
                "ApplicationContext.xml"
        );

   Unit unit = context.getBean("unit", Unit.class );
   Bazuka bazuka = context.getBean("bazuka", Bazuka.class );
   Arbalet arbalet = context.getBean("arbalet", Arbalet.class );
    //   unit.fireUnit();
    //    unit.fireUnit(arbalet, bazuka);
    Banda banda = context.getBean("banda", Banda.class);
        System.out.println(banda.toString());
    context.close();
    }
}