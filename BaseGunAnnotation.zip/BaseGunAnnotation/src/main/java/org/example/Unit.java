package org.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("unit")
public class Unit {
// name Gun
//   @Autowired
   private Gun gun;
//   @Autowired
   public void setGun(Gun gun) {  this.gun = gun;    }
// Конструкторы
//    @Autowired
   public Unit(Gun gun) { this.gun = gun; }
   public Unit() {    }
// name Unit
    private String name;
    public String getName() {  return name;    }
    public void setName(String name) {    this.name = name; }
// Power of Unit
    private int power;
    public int getPower() {  return power;    }
    public void setPower(int power) { this.power = power; }
// Fire of Unit
//    public void fireUnit() {
//        System.out.println("Стреляем - " + gun.getFire());
//    }
    public void fireUnit(Gun gun) {
        System.out.println("Стреляем - " + gun.getFire());
    }
// две зависимости одновременно
@Autowired
private Arbalet arbalet;
    @Autowired
private Bazuka bazuka;
    @Autowired
    public Unit(Arbalet arbalet, Bazuka bazuka) {
        this.arbalet = arbalet;
        this.bazuka = bazuka;
    }
    public void fireUnit(Arbalet arbalet, Bazuka bazuka) {
        System.out.println("Стреляем - " + arbalet.getFire());
        System.out.println("Стреляем - " + bazuka.getFire());
    }
}