package org.example;

public class ArbaletGun implements Gun {
    private String name;
    public String getName() {        return name;    }
    public void setName(String name) {        this.name = name;    }

    public ArbaletGun(String name) {
        this.name = name;
    }

    @Override
    public void fireGun() {
        System.out.println(name + " Вжик");
    }
}
