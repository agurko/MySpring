package org.example;

public class Unit {
    private String name;
    public Gun gun;
    public void fireUnit(Gun gun) {
        gun.fireGun();
    }
}
