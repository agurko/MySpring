package org.example;




public class Main {
    public static void main(String[] args) {

        System.out.println("Hello world!");
        Unit unit = new Unit();
        Gun gun1 = new BazukaGun("Базука");
        unit.fireUnit(gun1);
        Gun gun2 = new ArbaletGun("Арбалет");
        unit.fireUnit(gun2);

    }
}

