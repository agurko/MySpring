package org.example;

public class BazukaGun implements Gun {
    private String name;

    public BazukaGun(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public void fireGun() {
        System.out.println(name + " Бабах");
    }
}
