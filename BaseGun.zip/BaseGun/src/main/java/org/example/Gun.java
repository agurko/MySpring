package org.example;

public interface Gun {
    public void fireGun();
}
