package org.example;

public class Unit {
   private Gun gun;
   public Unit(Gun gun) {        this.gun = gun;    }
   public Unit() {    }
   public void setGun(Gun gun) {       this.gun = gun;    }
// name Unit
    private String name;
    public String getName() {        return name;    }
    public void setName(String name) {    this.name = name; }
// Power of Unit
    private int power;
    public int getPower() {       return power;    }
    public void setPower(int power) { this.power = power; }

    public void fireGun() {
        System.out.println("Стреляем - " + gun.getFire());
    }
}
