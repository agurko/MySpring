package org.example;
public class Arbalet implements Gun {
    @Override
    public String getFire() {
        return "ВЖИК";
    }

}
