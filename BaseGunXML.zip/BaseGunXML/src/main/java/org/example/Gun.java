package org.example;

public interface Gun {
    String getFire();
}
