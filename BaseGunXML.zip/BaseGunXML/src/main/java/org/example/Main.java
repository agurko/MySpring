package org.example;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.sql.SQLOutput;

public class Main {
    public static void main(String[] args) {
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
                "ApplicationContext.xml"
        );
        Gun gun = context.getBean("gunBean", Bazuka.class);
        System.out.println(gun.getFire());
    /*Unit firstUnit = context.getBean("unitBean", Unit.class );
    Unit secondUnit = context.getBean("unitBean", Unit.class );
    firstUnit.setPower(10);
        System.out.println(firstUnit.getName());
        System.out.println(firstUnit.getPower());
        System.out.println(secondUnit.getName());
        System.out.println(secondUnit.getPower());*/
    context.close();
    }
}