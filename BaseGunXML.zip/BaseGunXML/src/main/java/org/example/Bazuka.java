package org.example;
public class Bazuka implements Gun {
    // приватный конструктор запрещает создавать объекты с помощью new
    public Bazuka(){}
// Фабричный метод, он static
    public static Bazuka getBazuka() {
        return new Bazuka();
    }
    @Override
    public String getFire() {
        return "БАХ";
    }
    public void  doMyInit() {
        System.out.println("Initialization");
    }
    public void doMyDestroy(){
        System.out.println("Destroyed");
    }
}
